IBM Plex Sans supporting typeface specimen pack.
Replace this archive with licensed font files for download.
